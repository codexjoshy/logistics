<button {{ $attributes->merge(['class' => 'btn']) }}>
    {{ $slot }}
</button>
