<?php

namespace App\Services;

use App\Models\PlaceRequest;

class RiderService {
    
    public function riderIsBooked(int $rider)
    {
        
    }
}

?>