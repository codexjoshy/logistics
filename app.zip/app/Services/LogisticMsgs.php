<?php
    namespace App\Services;


class LogisticMsgs extends Messenger {
    protected $sender = [];
    protected $recipient = [];
    protected $rider;
    protected $company;

    /**
     * Undocumented function
     *
     * @param array $sender should contain ["name"=><name>, "phone"=><phone>]
     * @param array $recipient should contain ["name"=><name>, "phone"=><phone>]
     * @param array|null $rider should contain ["name"=><name>, "phone"=><phone>]
     * @param string|null $company name of the company
     */
    public function __construct(array $sender, array $recipient, ?array $rider=null, ?string $company=null) {
        $this->sender = $sender;
        $this->recipient = $recipient;
        $this->rider = $rider;
        $this->company = $company;
    }
    /**
     * Undocumented function
     *
     * @param string $person should contain rider|sender|receiver
     * @param string $otp
     * @param string|null $amount
     * @param string|null $pickupLocation
     * @param string|null $destination
     * @return array ["status"=> <status>, "error"=><>]
     */
    public function sendOTP(string $person, string $otp, ?string $amount=null, ?string $pickupLocation = null, ?string $destination = null, ?string $order=null)
    {
        $senderName = $this->sender['name'];
        $senderPhone = $this->sender['phone'];
        $receiverName = $this->recipient['name'];
        $receiverPhone = $this->recipient['phone'];

        if ($person == 'rider') {
            $message = "Pick up: $senderName($senderPhone) at  $pickupLocation Deliver: $receiverName($receiverPhone) $destination";
            $to = $this->rider['phone'];
        }
        if ($person == 'sender') {
            $showAmt = $amount ? "Amount: $amount" : '';
            $message = "Hi, $receiverName, your item from $senderName is in transit. Confirmation code: $otp, $showAmt Order id: $order booklogistic.com";
            $to = $senderPhone;
        }
        if ($person == 'receiver') {
            $showAmt = $amount ? "Amount: $amount" : '';
            $message = "Hi, $receiverName, your item from $senderName is in transit.
            Confirmation code: $otp, $showAmt booklogistic.com";
            $to = $receiverPhone;
        }
        $this->sendSMS($to, $message);
    }

    /**
     * send delivery  Message to the sender
     *
     * @return array ["status"=> <status>, "error"=><>]
     */
    public function deliveryMessage() 
    {
      $message = "Hi {$this->sender['name']}, your item has been successfully delivered to {$this->recipient['name']}.
      Thanks for your patronage {$this->company} booklogistic.com";
      return $this->sendSMS($this->_from, $this->sender['phone'], $message);
    }
}
    