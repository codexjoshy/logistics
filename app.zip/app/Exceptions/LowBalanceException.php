<?php

namespace App\Exceptions;

use Exception;

class LowBalanceException extends Exception
{
    //
}
